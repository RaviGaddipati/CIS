#include "hdr.h"

TEST_CASE("f2.cpp") {
    CHECK(1 == 0);
}
