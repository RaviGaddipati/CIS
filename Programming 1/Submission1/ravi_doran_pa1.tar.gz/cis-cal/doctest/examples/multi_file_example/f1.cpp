#include "hdr.h"

TEST_CASE("f1.cpp") {
    CHECK(1 == 0);
}
