#include "doctest.h"
#include <cstdio>

TEST_CASE("asd") { printf("hello from <lib_2_src.cpp>\n"); }
