#include "doctest.h"
#include <cstdio>

TEST_CASE("asd") { printf("hello from <lib_1_src1.cpp>\n"); }
